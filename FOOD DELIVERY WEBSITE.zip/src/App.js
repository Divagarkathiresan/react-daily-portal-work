import React from "react";
import LoginPage from './loginpage';

function App() {
  return (
    <div>
      <LoginPage />
    </div>
  );
}

export default App;
